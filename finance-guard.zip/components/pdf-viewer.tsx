"use client"

import { useState, useEffect } from "react"
import { ChevronLeft, ChevronRight, Search, ZoomIn, ZoomOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Skeleton } from "@/components/ui/skeleton"
import { useToast } from "@/hooks/use-toast"

interface PdfViewerProps {
  fileId: string
  onTextSelect: (text: string) => void
  isLoading: boolean
}

export function PdfViewer({ fileId, onTextSelect, isLoading }: PdfViewerProps) {
  const [pageNumber, setPageNumber] = useState(1)
  const [totalPages, setTotalPages] = useState(10) // Mock total pages
  const [scale, setScale] = useState(1.0)
  const [searchText, setSearchText] = useState("")
  const [isLoadingPdf, setIsLoadingPdf] = useState(true)
  const { toast } = useToast()

  // Use the example.pdf from public/sample folder
  const pdfUrl = "/sample/example.pdf"

  useEffect(() => {
    // Reset state when fileId changes
    setIsLoadingPdf(true)

    // Simulate loading a PDF after a delay
    const timer = setTimeout(() => {
      setIsLoadingPdf(false)

      // Simulate getting total pages from the PDF
      if (fileId.startsWith("sample_")) {
        setTotalPages(15) // Mock number of pages for our sample PDF
      }

      toast({
        title: "Document loaded",
        description: "Financial document has been loaded successfully",
      })
    }, 1500)

    return () => clearTimeout(timer)
  }, [fileId, toast])

  const handlePreviousPage = () => {
    setPageNumber((prevPageNumber) => Math.max(prevPageNumber - 1, 1))
    // In a real implementation, you would control the PDF viewer to go to the previous page
  }

  const handleNextPage = () => {
    setPageNumber((prevPageNumber) => Math.min(prevPageNumber + 1, totalPages))
    // In a real implementation, you would control the PDF viewer to go to the next page
  }

  const handleZoomIn = () => {
    setScale((prevScale) => Math.min(prevScale + 0.2, 3))
    // In a real implementation, you would control the PDF viewer zoom
  }

  const handleZoomOut = () => {
    setScale((prevScale) => Math.max(prevScale - 0.2, 0.6))
    // In a real implementation, you would control the PDF viewer zoom
  }

  const handleTextSelection = () => {
    // In a real implementation, you would get the selected text from the PDF viewer
    // For demo purposes, we'll simulate text selection with financial content
    const financialTerms = [
      "The annual management fee is 1.5% of assets under management.",
      "Early redemption penalties apply for withdrawals within the first 3 years.",
      "Market risk may result in substantial loss of principal.",
      "This product is not FDIC insured and may lose value.",
      "The liquidity of this investment is limited, with quarterly redemption windows.",
      "Performance fees of 20% apply to returns above the benchmark.",
    ]

    // Select a random financial term
    const selectedText = financialTerms[Math.floor(Math.random() * financialTerms.length)]
    onTextSelect(selectedText)

    toast({
      title: "Text selected",
      description: "The selected text has been added to the chatbot",
    })
  }

  const handleSearch = () => {
    if (!searchText) return

    toast({
      title: "Searching document",
      description: `Searching for "${searchText}" in the document`,
    })

    // In a real implementation, you would search the PDF for the text
  }

  if (isLoading || isLoadingPdf) {
    return (
      <div className="flex flex-col h-full">
        <div className="flex items-center justify-between p-2 border-b">
          <div className="flex items-center space-x-2">
            <Skeleton className="h-8 w-8 rounded-md" />
            <Skeleton className="h-8 w-8 rounded-md" />
          </div>
          <div className="flex items-center space-x-2">
            <Skeleton className="h-8 w-24 rounded-md" />
          </div>
          <div className="flex items-center space-x-2">
            <Skeleton className="h-8 w-8 rounded-md" />
            <Skeleton className="h-8 w-8 rounded-md" />
            <Skeleton className="h-8 w-8 rounded-md" />
          </div>
        </div>
        <div className="flex-1 flex items-center justify-center bg-muted/20">
          <div className="text-center space-y-4">
            <Skeleton className="h-[400px] w-[300px] mx-auto" />
            <p className="text-muted-foreground">Loading document...</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between p-2 border-b">
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="icon" onClick={handlePreviousPage} disabled={pageNumber <= 1}>
            <ChevronLeft className="h-4 w-4" />
            <span className="sr-only">Previous page</span>
          </Button>
          <Button variant="outline" size="icon" onClick={handleNextPage} disabled={pageNumber >= totalPages}>
            <ChevronRight className="h-4 w-4" />
            <span className="sr-only">Next page</span>
          </Button>
        </div>
        <div className="flex items-center space-x-2">
          <span className="text-sm">
            Page {pageNumber} of {totalPages}
          </span>
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="icon" onClick={handleZoomOut}>
            <ZoomOut className="h-4 w-4" />
            <span className="sr-only">Zoom out</span>
          </Button>
          <Button variant="outline" size="icon" onClick={handleZoomIn}>
            <ZoomIn className="h-4 w-4" />
            <span className="sr-only">Zoom in</span>
          </Button>
          <div className="relative">
            <Input
              type="text"
              placeholder="Search..."
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
              className="h-8 w-32 pl-8"
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
            />
            <Search className="absolute left-2 top-2 h-4 w-4 text-muted-foreground" />
          </div>
        </div>
      </div>
      <div className="flex-1 overflow-hidden bg-muted/20 flex justify-center" onClick={handleTextSelection}>
        <iframe
          src={pdfUrl}
          className="w-full h-full border-none"
          title="PDF Document Viewer"
          sandbox="allow-scripts allow-same-origin"
        />
      </div>
    </div>
  )
}

